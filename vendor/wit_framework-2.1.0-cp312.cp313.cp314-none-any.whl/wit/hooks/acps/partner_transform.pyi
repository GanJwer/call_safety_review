from _typeshed import Incomplete
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any
from wit.kernel.content import ContentPart
from wit.kernel.hooks import WitAipHooks
from wit.providers import Message

__all__ = ['AipPartnerTransformHooks', 'AipPartnerRequestEvent', 'AipPartnerResponseEvent']

@dataclass(frozen=True, slots=True)
class AipPartnerRequestEvent:
    """One validated inbound command before its business content reaches the Agent.

    Protocol identity and command fields are read-only. Hooks may replace
    the Agent-facing ``messages`` history and current ``content``. They may keep
    JSON-serializable, host-only values in ``local_context``. The context is
    persisted with this Task's AgentState but is not added to the model prompt
    or projected onto the AIP wire.
    """
    task_ref: str
    command: PartnerRequestCommand
    task_id: str
    session_id: str
    command_id: str
    sent_at: str
    leader_aic: str
    partner_aic: str
    delivery: PartnerDelivery
    peer_verified: bool
    data_items: tuple[Mapping[str, Any], ...]
    command_params: Mapping[str, Any]
    messages: list[Message]
    content: list[ContentPart]
    local_context: dict[str, Any] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AipPartnerResponseEvent:
    """One Partner business result before it is persisted and exposed remotely.

    Hooks may replace ``products`` or ``data_items``. The executor validates
    the transformed payload again before changing Task state. Protocol identity
    and the target state remain read-only.
    """
    task_ref: str
    task_id: str
    session_id: str
    leader_aic: str
    partner_aic: str
    delivery: PartnerDelivery
    source: PartnerResponseSource
    state: PartnerResponseState
    products: list[dict[str, Any]] = field(default_factory=list)
    data_items: list[dict[str, Any]] = field(default_factory=list)
    local_context: Mapping[str, Any] = field(default_factory=Incomplete)
    def __post_init__(self) -> None: ...

class AipPartnerTransformHooks(WitAipHooks):
    """Intercept Agent-facing AIP Partner input and Partner business output.

    Register this protocol-layer hook through
    ``WitAgent.aip_hooks``. It is dispatched by the shared Partner
    executor and does not participate in the generic Agent run lifecycle.

    This hook deliberately sits above HTTP, SSE, Notification, and AMQP.
    Transport validation, peer authentication, Task identity, and protocol state
    transitions remain framework-owned.
    """
    id: str
    priority: int
    async def on_partner_request(self, event: AipPartnerRequestEvent) -> None: ...
    async def on_partner_response(self, event: AipPartnerResponseEvent) -> None: ...
