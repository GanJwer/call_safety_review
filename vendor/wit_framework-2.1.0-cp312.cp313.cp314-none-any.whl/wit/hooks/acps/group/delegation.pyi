from typing import Any
from wit.acps.aip import AipError as AipError, INVALID_PARAMS as INVALID_PARAMS
from wit.acps.tool_support import TOOL_CONTENT_INPUT_SCHEMA as TOOL_CONTENT_INPUT_SCHEMA, add_discovery_tool as add_discovery_tool, tool_content_input as tool_content_input
from wit.kernel.capabilities import Tool as Tool
from wit.kernel.context import ContextBlock as ContextBlock
from wit.kernel.hooks import HookContext as HookContext, RunStartEvent as RunStartEvent, WitHooks as WitHooks

class AipGroupDelegationHooks(WitHooks):
    """Expose high-level Leader Group operations without infrastructure secrets."""
    id: str
    priority: int
    async def on_run_start(self, event: RunStartEvent) -> None: ...
    def context(self, ctx: HookContext) -> list[ContextBlock]: ...

def _optional_string(args: dict[str, Any], name: str) -> str | None: ...
def _optional_string_list(args: dict[str, Any], name: str) -> list[str] | None: ...
