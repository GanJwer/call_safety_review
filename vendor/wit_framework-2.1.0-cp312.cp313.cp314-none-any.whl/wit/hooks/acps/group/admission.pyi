from _typeshed import Incomplete
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime
from typing import Literal, TypeAlias
from wit.acps.group.models import ensure_valid_aic as ensure_valid_aic, ensure_valid_group_id as ensure_valid_group_id
from wit.kernel.hooks import WitAipHooks as WitAipHooks

@dataclass(frozen=True, slots=True)
class AipGroupAdmissionRequest:
    """Secret-free Host context for accepting or rejecting Group membership."""
    group_id: str
    leader_aic: str
    partner_aic: str
    members: tuple[str, ...]
    delivery: Literal['inbox', 'rpc']
    expires_at: datetime | None
    publisher_verified: bool
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AipGroupAdmissionDecision:
    state: Literal['accepted', 'rejected']
    reason: str | None = ...
    def __post_init__(self) -> None: ...
    @classmethod
    def accept(cls) -> AipGroupAdmissionDecision: ...
    @classmethod
    def reject(cls, reason: str) -> AipGroupAdmissionDecision: ...
AipGroupAdmissionHandler: TypeAlias = Callable[[AipGroupAdmissionRequest], AipGroupAdmissionDecision | Awaitable[AipGroupAdmissionDecision]]

class AipGroupAdmissionHooks(WitAipHooks):
    """Explicit Host policy for unsolicited Partner Group invitations.

    Register this protocol-layer hook through
    ``WitAgent.aip_hooks``. It is dispatched by the Group coordinator
    and does not participate in the generic Agent run lifecycle.
    """
    id: str
    priority: int
    handler: Incomplete
    def __init__(self, handler: AipGroupAdmissionHandler) -> None: ...
    async def decide_admission(self, request: AipGroupAdmissionRequest) -> AipGroupAdmissionDecision: ...
