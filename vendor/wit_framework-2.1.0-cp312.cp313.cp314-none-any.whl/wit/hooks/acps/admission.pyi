from _typeshed import Incomplete
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from typing import Any, Literal, TypeAlias
from wit.kernel.hooks import WitAipHooks as WitAipHooks

@dataclass(frozen=True, slots=True)
class AipPartnerAdmissionRequest:
    """Validated, read-only context for deciding whether to accept an AIP Task.

    Admission runs after protocol and peer-identity validation, but before the
    inbound Task receives its first state or any Partner Agent work is started.
    The callback must treat all Leader-provided content as untrusted data.
    """
    task_id: str
    session_id: str
    command_id: str
    sent_at: str
    leader_aic: str
    partner_aic: str
    delivery: Literal['rpc', 'stream', 'notification', 'group']
    peer_verified: bool
    data_items: tuple[Mapping[str, Any], ...] = ...
    command_params: Mapping[str, Any] = field(default_factory=Incomplete)
    def __post_init__(self) -> None: ...
    @classmethod
    def from_command(cls, command: Mapping[str, Any], *, leader_aic: str, partner_aic: str, delivery: Literal['rpc', 'stream', 'notification', 'group'], peer_verified: bool) -> AipPartnerAdmissionRequest: ...
    @property
    def text_items(self) -> tuple[str, ...]:
        """Return the Leader's text DataItems without changing their order."""

@dataclass(frozen=True, slots=True)
class AipPartnerAdmissionDecision:
    """The only two protocol-valid outcomes of Partner admission."""
    state: Literal['accepted', 'rejected']
    reason: str | None = ...
    def __post_init__(self) -> None: ...
    @classmethod
    def accept(cls) -> AipPartnerAdmissionDecision: ...
    @classmethod
    def reject(cls, reason: str) -> AipPartnerAdmissionDecision: ...
AipPartnerAdmissionHandler: TypeAlias = Callable[[AipPartnerAdmissionRequest], AipPartnerAdmissionDecision | Awaitable[AipPartnerAdmissionDecision]]

class AipPartnerAdmissionHooks(WitAipHooks):
    """Run an explicit Partner admission policy before accepting an AIP Task.

    Register this protocol-layer hook through
    ``WitAgent.aip_hooks``. It is dispatched by AIP coordinators and
    does not participate in the generic Agent run lifecycle.

    With no such hook configured, the Partner retains the framework's
    default accept behavior. Multiple admission hooks are evaluated in
    hook priority order; the first rejection wins.
    """
    id: str
    priority: int
    handler: Incomplete
    def __init__(self, handler: AipPartnerAdmissionHandler) -> None: ...
    async def decide_admission(self, request: AipPartnerAdmissionRequest) -> AipPartnerAdmissionDecision: ...

def _freeze(value: Any) -> Any: ...
