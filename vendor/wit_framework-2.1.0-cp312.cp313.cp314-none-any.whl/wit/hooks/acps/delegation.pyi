from _typeshed import Incomplete
from wit.acps.aip import AipError as AipError, validate_notify_on_states as validate_notify_on_states
from wit.acps.tool_support import TOOL_CONTENT_INPUT_SCHEMA as TOOL_CONTENT_INPUT_SCHEMA, add_discovery_tool as add_discovery_tool, tool_content_input as tool_content_input
from wit.kernel.capabilities import Tool as Tool
from wit.kernel.context import ContextBlock as ContextBlock
from wit.kernel.hooks import HookContext as HookContext, RunStartEvent as RunStartEvent, WitHooks as WitHooks

class AipDelegationHooks(WitHooks):
    """Give a Wit agent high-level AIP discovery and delegation tools."""
    id: str
    priority: int
    delivery: Incomplete
    notify_on_states: Incomplete
    def __init__(self, *, delivery: str = 'rpc', notify_on_states: list[str] | tuple[str, ...] | None = None) -> None: ...
    async def on_run_start(self, event: RunStartEvent) -> None: ...
    def context(self, ctx: HookContext) -> list[ContextBlock]: ...
