from _typeshed import Incomplete
from dataclasses import dataclass, field
from typing import Any, Literal, Sequence, TypeAlias

__all__ = ['ATTACHMENT_PART_TYPES', 'AttachmentPart', 'AudioPart', 'CONTENT_PART_TYPES', 'ContentKind', 'ContentInput', 'ContentPart', 'DataPart', 'FileDetail', 'FilePart', 'ImageDetail', 'ImagePart', 'ReasoningPart', 'RefusalPart', 'TextPart', 'VideoPart', 'attachment_summary', 'content_part_text', 'normalize_content', 'reasoning_part_text']

ContentKind: TypeAlias
ImageDetail: TypeAlias
FileDetail: TypeAlias

@dataclass(frozen=True, slots=True)
class TextPart:
    text: str
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['text'] = field(default='text', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class ReasoningPart:
    """Provider-neutral model reasoning kept separate from final answer text."""
    text: str
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['reasoning'] = field(default='reasoning', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class RefusalPart:
    text: str
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['refusal'] = field(default='refusal', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class DataPart:
    data: Any
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['data'] = field(default='data', init=False)

@dataclass(frozen=True, slots=True)
class ImagePart:
    mime_type: str
    uri: str | None = ...
    data: bytes | None = ...
    name: str | None = ...
    detail: ImageDetail = ...
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['image'] = field(default='image', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class VideoPart:
    mime_type: str
    uri: str | None = ...
    data: bytes | None = ...
    name: str | None = ...
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['video'] = field(default='video', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AudioPart:
    mime_type: str
    uri: str | None = ...
    data: bytes | None = ...
    name: str | None = ...
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['audio'] = field(default='audio', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class FilePart:
    uri: str | None = ...
    data: bytes | None = ...
    mime_type: str | None = ...
    name: str | None = ...
    detail: FileDetail = ...
    metadata: dict[str, Any] = field(default_factory=_metadata)
    type: Literal['file'] = field(default='file', init=False)
    def __post_init__(self) -> None: ...
ContentPart: TypeAlias = TextPart | ReasoningPart | RefusalPart | DataPart | ImagePart | VideoPart | AudioPart | FilePart
AttachmentPart: TypeAlias = ImagePart | VideoPart | AudioPart | FilePart
ContentInput: TypeAlias = str | ContentPart | Sequence[ContentPart]
CONTENT_PART_TYPES: Incomplete
ATTACHMENT_PART_TYPES: Incomplete

def normalize_content(value: ContentInput | None) -> list[ContentPart]:
    """Normalize developer-friendly input to the single internal list shape."""
def content_part_text(value: str | Sequence[ContentPart]) -> str:
    """Return final text/refusal without mixing in reasoning or attachments."""
def reasoning_part_text(value: Sequence[ContentPart]) -> str:
    """Return only provider-neutral reasoning text."""
def attachment_summary(part: AttachmentPart) -> dict[str, Any]:
    """Return telemetry-safe attachment metadata without raw bytes."""
