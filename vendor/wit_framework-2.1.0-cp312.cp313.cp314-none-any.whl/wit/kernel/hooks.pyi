from ..acps.amp import AmpHandle as AmpHandle
from ..providers import ContentTransform as ContentTransform
from .agent import CompiledAgent as CompiledAgent
from .capabilities import Tool as Tool, ToolManager as ToolManager
from .context import BuildContext as BuildContext, ContextBlock as ContextBlock, StateSlot as StateSlot
from .messages import ModelRequest as ModelRequest, ModelResponse as ModelResponse, ToolCall as ToolCall
from .runtime import AgentState as AgentState, RunConfig as RunConfig, RunResult as RunResult, WitRuntime as WitRuntime
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

@dataclass
class HookContext:
    runtime: WitRuntime
    compiled: CompiledAgent
    state: AgentState
    config: RunConfig
    workspace: Path
    private_state: dict[str, Any]
    tool_manager: ToolManager
    content_transforms: list[ContentTransform] = field(default_factory=list)
    tool_conflicts: list[dict[str, Any]] = field(default_factory=list)
    def add_tool(self, tool: Tool, *, source: str = 'hook') -> Tool:
        """Add a run-scoped tool, replacing any build-time tool of the same name.

        Injection happens mid-run, so raising on a name collision would abort the
        whole run with an error that points at the symptom rather than the cause.
        The collision is recorded instead; ``compile()`` already reports reserved
        protocol prefixes as an error diagnostic.
        """
    def add_content_transform(self, transform: ContentTransform) -> ContentTransform:
        """Add a content transform for this run only."""
    @property
    def amp(self) -> AmpHandle:
        """Return the runtime's lazy, active-AIC AMP handle."""

@dataclass
class RunStartEvent:
    context: HookContext

@dataclass
class ModelRequestEvent:
    context: HookContext
    model: Any
    request: ModelRequest
    def add_tool(self, tool: Tool, *, source: str = 'hook') -> Tool: ...

@dataclass
class ModelResponseEvent:
    context: HookContext
    model: Any
    request: ModelRequest
    response: ModelResponse

@dataclass
class ToolRequestEvent:
    context: HookContext
    tools: dict[str, Tool]
    tool: Tool | None
    tool_call: ToolCall

@dataclass
class ToolResponseEvent:
    context: HookContext
    tools: dict[str, Tool]
    tool: Tool | None
    tool_call: ToolCall
    response: dict[str, Any]

@dataclass
class StepStartEvent:
    context: HookContext
    step: int

@dataclass
class StepEndEvent:
    context: HookContext
    step: int
    observations: list[dict[str, Any]]

@dataclass
class RunEndEvent:
    context: HookContext
    result: RunResult

class WitAipHooks:
    """Metadata base for hooks consumed by the AIP protocol layer."""
    id: str
    priority: int

class WitAmpHooks:
    """Metadata base for hooks consumed by the AMP protocol layer."""
    id: str
    priority: int

class WitHooks:
    id: str
    priority: int
    def tools(self, ctx: BuildContext) -> list[Tool]: ...
    def content_transforms(self, ctx: BuildContext) -> list[ContentTransform]: ...
    def context(self, ctx: HookContext) -> list[ContextBlock]: ...
    def state(self, ctx: BuildContext) -> dict[str, StateSlot]: ...
    async def on_run_start(self, event: RunStartEvent) -> None: ...
    async def wrap_run(self, ctx: HookContext, handler: Callable[[], Awaitable[RunResult]]) -> RunResult: ...
    async def on_model_request(self, event: ModelRequestEvent) -> None: ...
    async def wrap_model_call(self, ctx: HookContext, request: ModelRequest, handler: Callable[[ModelRequest], Awaitable[ModelResponse]]) -> ModelResponse: ...
    async def on_model_response(self, event: ModelResponseEvent) -> None: ...
    async def on_tool_request(self, event: ToolRequestEvent) -> None: ...
    async def wrap_tool_call(self, ctx: HookContext, tool_call: ToolCall, handler: Callable[[ToolCall], Awaitable[dict[str, Any]]]) -> dict[str, Any]: ...
    async def on_tool_response(self, event: ToolResponseEvent) -> None: ...
    async def on_step_start(self, event: StepStartEvent) -> None: ...
    async def on_step_end(self, event: StepEndEvent) -> None: ...
    async def on_run_end(self, event: RunEndEvent) -> None: ...
