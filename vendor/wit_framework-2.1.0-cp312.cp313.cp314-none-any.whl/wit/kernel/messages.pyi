from .content import ContentPart
from _typeshed import Incomplete
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

__all__ = ['Message', 'ModelRequest', 'ModelResponse', 'ModelStreamEvent', 'ToolCall']

@dataclass(frozen=True, slots=True)
class ToolCall:
    id: str
    name: str
    arguments: Mapping[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class Message:
    role: str
    content: list[ContentPart] = field(default_factory=list)
    name: str | None = ...
    tool_call_id: str | None = ...
    tool_calls: list[ToolCall] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    def __post_init__(self) -> None: ...
    def text(self) -> str: ...
    def reasoning(self) -> str: ...

@dataclass(slots=True)
class ModelRequest:
    messages: list[Message]
    tools: list[Any] = field(default_factory=list)
    settings: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class ModelResponse:
    message: Message = field(default_factory=Incomplete)
    finish_reason: str | None = ...
    metadata: dict[str, Any] = field(default_factory=dict)
    @property
    def output_parts(self) -> list[ContentPart]: ...
    @property
    def final_text(self) -> str: ...
    @property
    def reasoning_text(self) -> str: ...
    @property
    def tool_calls(self) -> list[ToolCall]: ...
    @classmethod
    def final(cls, content: str | ContentPart | Sequence[ContentPart], *, metadata: Mapping[str, Any] | None = None) -> ModelResponse: ...
    @classmethod
    def tools(cls, calls: list[ToolCall]) -> ModelResponse: ...

@dataclass(slots=True)
class ModelStreamEvent:
    event: str
    data: Mapping[str, Any] = field(default_factory=dict)
    response: ModelResponse | None = ...
    metadata: dict[str, Any] = field(default_factory=dict)
