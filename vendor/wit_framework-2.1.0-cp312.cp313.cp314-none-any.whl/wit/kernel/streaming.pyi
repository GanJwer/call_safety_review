from .content import ATTACHMENT_PART_TYPES as ATTACHMENT_PART_TYPES, DataPart as DataPart, ReasoningPart as ReasoningPart, RefusalPart as RefusalPart, TextPart as TextPart, attachment_summary as attachment_summary
from _typeshed import Incomplete
from dataclasses import dataclass, field
from typing import Any, Mapping

@dataclass(frozen=True)
class WitStreamEvent:
    event: str
    name: str
    run_id: str
    parent_ids: list[str] = field(default_factory=list)
    data: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    def to_dict(self) -> dict[str, Any]: ...

def stream_id(prefix: str) -> str: ...
def _plain(value: Any) -> Any: ...

_BINARY_KEYS: Incomplete
_BASE64: Incomplete

def _is_encoded_binary(key: str, value: Any) -> bool: ...
