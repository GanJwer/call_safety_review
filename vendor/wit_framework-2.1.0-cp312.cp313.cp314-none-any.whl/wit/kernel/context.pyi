from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

@dataclass(frozen=True)
class BuildContext:
    """What a hook can see at ``compile()`` time."""
    agent_id: str
    workspace: Path | None = ...
    metadata: Mapping[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class ContextBlock:
    """A block a hook contributes to the system prompt.

    ``trusted=False`` marks content that came from outside the agent, so the
    rendered block tells the model to treat it as data rather than instruction.
    """
    title: str
    value: Any
    kind: str = ...
    trusted: bool = ...
    metadata: Mapping[str, Any] = field(default_factory=dict)
    @classmethod
    def text(cls, *, title: str, value: str, trusted: bool = True, metadata: Mapping[str, Any] | None = None) -> ContextBlock: ...
    @classmethod
    def state(cls, *, title: str, value: Any, trusted: bool = True, metadata: Mapping[str, Any] | None = None) -> ContextBlock: ...
    def render(self) -> str: ...

@dataclass(frozen=True)
class StateSlot:
    """A declared key in the run-scoped private state a hook owns."""
    default: Any = ...
    description: str | None = ...
    metadata: Mapping[str, Any] = field(default_factory=dict)
    def default_value(self) -> Any: ...
