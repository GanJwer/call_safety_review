from _typeshed import Incomplete

SDK_DISTRIBUTION: str
SDK_VERSION: str
SDK_WHEEL_REQUIREMENT: str
_PREREQUISITE_MESSAGE: Incomplete

def _prerequisite_error() -> ModuleNotFoundError: ...
def _import_required_module(name: str) -> None: ...
def ensure_sdk_prerequisite() -> None: ...
