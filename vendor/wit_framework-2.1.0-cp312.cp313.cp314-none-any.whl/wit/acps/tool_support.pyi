from ..kernel.capabilities import Tool
from ..kernel.content import ContentInput
from ..kernel.hooks import HookContext
from collections.abc import Awaitable, Callable
from typing import Any

__all__ = ['DISCOVERY_TOOL_SCHEMA', 'TOOL_CONTENT_INPUT_SCHEMA', 'TOOL_CONTENT_PART_SCHEMA', 'add_discovery_tool', 'tool_content_input']

TOOL_CONTENT_PART_SCHEMA: dict[str, Any]
TOOL_CONTENT_INPUT_SCHEMA: dict[str, Any]
DISCOVERY_TOOL_SCHEMA: dict[str, Any]

def add_discovery_tool(ctx: HookContext, *, discover: Callable[..., Awaitable[dict[str, Any]]]) -> Tool:
    """Install exactly one shared Discovery tool in Direct, Group, or Hybrid runs."""
def tool_content_input(value: Any, *, field: str) -> ContentInput:
    """Parse the URI-only semantic shape exposed to model ToolCalls."""
