from dataclasses import dataclass
from pathlib import Path
from typing import Any

@dataclass(frozen=True)
class CertificatePaths:
    client_certificate: Path
    client_private_key: Path
    server_certificate: Path
    server_private_key: Path
    trust_bundle: Path
    def to_dict(self) -> dict[str, str]: ...

@dataclass(frozen=True)
class IdentityRef:
    aic: str
    provenance: str
    def to_dict(self) -> dict[str, Any]: ...

@dataclass(frozen=True)
class ResolvedAcpsIdentity:
    ref: IdentityRef
    status: str
    certificate_paths: CertificatePaths | None = ...
    metadata: dict[str, Any] | None = ...
    @property
    def aic(self) -> str: ...
    def to_dict(self) -> dict[str, Any]: ...
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResolvedAcpsIdentity: ...
