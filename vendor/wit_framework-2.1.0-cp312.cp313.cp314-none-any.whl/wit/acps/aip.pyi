from ..kernel.content import AudioPart as AudioPart, ContentInput as ContentInput, ContentPart as ContentPart, DataPart as DataPart, FilePart as FilePart, ImagePart as ImagePart, ReasoningPart as ReasoningPart, RefusalPart as RefusalPart, TextPart as TextPart, VideoPart as VideoPart, normalize_content as normalize_content
from _typeshed import Incomplete
from pydantic import BaseModel, ValidationError
from typing import Any, Literal, Mapping, Sequence

JSONRPC_VERSION: str
MAX_INLINE_FILE_BYTES: Incomplete
PARSE_ERROR: int
INVALID_REQUEST: int
METHOD_NOT_FOUND: int
INVALID_PARAMS: int
INTERNAL_ERROR: int
TASK_NOT_FOUND: int
TASK_NOT_CANCELABLE: int
NOTIFICATION_NOT_SUPPORTED: int
UNSUPPORTED_OPERATION: int
CONTENT_TYPE_NOT_SUPPORTED: int
INVALID_AGENT_RESPONSE: int
GROUP_NOT_SUPPORTED: int
AUTHENTICATION_REQUIRED: int
AUTHORIZATION_FAILED: int
ACCESS_TOKEN_INVALID: int
TASK_STATES: Incomplete
TERMINAL_TASK_STATES: Incomplete
RPC_COMMANDS: Incomplete
STREAM_COMMANDS: Incomplete
VALID_TRANSITIONS: dict[str | None, set[str]]

class AipError(Exception):
    code: Incomplete
    message: Incomplete
    data: Incomplete
    def __init__(self, code: int, message: str, data: Any = None) -> None: ...

class _AipModel(BaseModel):
    model_config: Incomplete

class TextDataItem(_AipModel):
    type: Literal['text']
    text: str
    metadata: dict[str, Any] | None

class FileDataItem(_AipModel):
    type: Literal['file']
    name: str | None
    mime_type: str | None
    uri: str | None
    bytes: str | None
    metadata: dict[str, Any] | None
    def validate_content(self) -> FileDataItem: ...

class StructuredDataItem(_AipModel):
    type: Literal['data']
    data: dict[str, Any]
    metadata: dict[str, Any] | None

DataItem: Incomplete

class Product(_AipModel):
    id: str
    name: str | None
    description: str | None
    data_items: list[DataItem]
    def to_aip(self) -> dict[str, Any]: ...

DATA_ITEM_JSON_SCHEMA: dict[str, Any]
PRODUCT_JSON_SCHEMA: dict[str, Any]
TOOL_PRODUCT_JSON_SCHEMA: dict[str, Any]

def utc_now() -> str: ...
def message_id(prefix: str = 'msg') -> str: ...
def jsonrpc_success(request_id: str | int | None, result: Any) -> dict[str, Any]: ...
def jsonrpc_error(request_id: str | int | None, code: int, message: str, data: Any = None) -> dict[str, Any]: ...
def validate_jsonrpc_request(value: Any) -> dict[str, Any]: ...
def request_id(request: Mapping[str, Any] | None) -> str | int | None: ...
def jsonrpc_response_expected(request: Mapping[str, Any]) -> bool:
    """Return whether a valid request asks the server to send a response."""
def validate_rpc_command(params: Any, *, key: str = 'command') -> dict[str, Any]: ...
def validate_stream_command(params: Any) -> dict[str, Any]: ...
def validate_notification_config(value: Any) -> dict[str, Any]: ...
def validate_notification_id_request(value: Any) -> dict[str, Any]: ...
def validate_notification_start_command(value: Any) -> dict[str, Any]: ...
def validate_notify_on_states(value: Any) -> list[str] | None: ...
def _validate_task_command(params: Any, *, key: str, allowed_commands: set[str], validate_command_params: bool = True) -> dict[str, Any]: ...
def _validate_command_params(command: str, value: Any) -> None: ...
def _validate_start_command_params(value: Mapping[str, Any] | None) -> None: ...
def _validate_restream_command_params(value: Mapping[str, Any] | None) -> None: ...
def validate_data_items(value: Any) -> list[dict[str, Any]]: ...
def validate_product(value: Any) -> dict[str, Any]: ...
def validate_products(value: Any) -> list[dict[str, Any]]: ...
def data_item_to_tool(value: Mapping[str, Any]) -> dict[str, Any]:
    """Project one validated AIP DataItem into the model-facing snake_case shape."""
def product_to_tool(value: Mapping[str, Any]) -> dict[str, Any]:
    """Project one validated AIP Product into the model-facing snake_case shape."""
def products_to_tool(values: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]: ...
def _validation_reason(exc: ValidationError) -> str: ...
def task_status(state: str, *, data_items: Any = None, at: str | None = None) -> dict[str, Any]: ...
def can_transition(current: str | None, target: str) -> bool: ...
def normalize_data_items(value: Any) -> list[dict[str, Any]]: ...
def text_data_item(text: str) -> dict[str, Any]: ...
def text_product(*, task_id: str, text: str, product_id: str | None = None, name: str = 'Agent response') -> dict[str, Any]: ...
def content_product(*, task_id: str, parts: Sequence[ContentPart], product_id: str | None = None, name: str = 'Agent response', description: str | None = None) -> dict[str, Any]: ...
def file_product(*, task_id: str, part: ImagePart | VideoPart | AudioPart | FilePart, product_id: str | None = None, name: str = 'Agent response', description: str | None = None) -> dict[str, Any]: ...
_MediaPartType = type[ImagePart] | type[VideoPart] | type[AudioPart] | type[FilePart]
_CONTENT_PART_KIND_BY_MIME_PREFIX: dict[str, _MediaPartType]

def _content_part_kind(mime_type: str | None) -> _MediaPartType: ...
def content_part_to_data_item(part: ContentPart) -> dict[str, Any]:
    """Project a business-layer ``ContentPart`` onto an AIP ``DataItem``.

    Text and provider refusals become ordinary ``TextDataItem`` values. Every
    attachment kind (image/video/audio/file) collapses onto ``FileDataItem`` --
    the AIP spec has no per-modality file type, only ``file`` + ``mimeType``, so
    the modality distinction is recovered on the way back in by sniffing the
    mime type prefix. Provider reasoning has no AIP wire projection and fails
    closed.
    """
def content_parts_to_data_items(parts: Sequence[ContentPart]) -> list[dict[str, Any]]: ...
def content_input_to_data_items(value: ContentInput | None) -> list[dict[str, Any]]:
    """Convert developer-facing content into validated AIP wire DataItems."""
def data_item_to_content_part(item: Mapping[str, Any]) -> ContentPart:
    """Inverse of :func:`content_part_to_data_item`.

    Every AIP DataItem has a semantic ContentPart counterpart. Remote text is
    always public ``TextPart`` semantics; metadata cannot re-type it as an
    internal provider part. Structured data stays structured until an explicit
    model-facing projection renders it.
    """
def data_items_to_content_parts(items: Sequence[Mapping[str, Any]]) -> list[ContentPart]: ...
def _aip_metadata(metadata: Mapping[str, Any]) -> dict[str, Any]:
    """Drop provider-private state before crossing the AIP trust boundary."""
def _data_item_metadata(item: Mapping[str, Any]) -> dict[str, Any]:
    """Read only public metadata from an untrusted AIP DataItem."""
def task_result(*, partner_aic: str, task_id: str, state: str, state_changed_at: str, session_id: str | None = None, products: list[dict[str, Any]] | None = None, status_data_items: list[dict[str, Any]] | None = None, command_history: list[dict[str, Any]] | None = None, status_history: list[dict[str, Any]] | None = None, message_id_prefix: str = 'result') -> dict[str, Any]: ...
