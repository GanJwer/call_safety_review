from pathlib import Path
from typing import Any

SECRET_MODE: int
PUBLIC_MODE: int

def atomic_write_bytes(path: Path, payload: bytes, *, mode: int = ...) -> Path: ...
def atomic_write_text(path: Path, text: str, *, mode: int = ...) -> Path: ...
def atomic_write_json(path: Path, payload: Any, *, mode: int = ...) -> Path: ...
def read_json_or_none(path: Path) -> Any | None:
    """Read JSON, treating a corrupt file as absent rather than raising."""
