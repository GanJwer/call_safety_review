import ssl
from ..bindings import ACPS_GROUP_RUNTIME_PROFILE as ACPS_GROUP_RUNTIME_PROFILE
from ..identity import CertificatePaths as CertificatePaths
from .models import INBOX_EXCHANGE as INBOX_EXCHANGE, ensure_valid_aic as ensure_valid_aic, group_exchange_name as group_exchange_name, group_queue_name as group_queue_name, inbox_queue_name as inbox_queue_name, wire_sender_id as wire_sender_id
from .tls import MtlsClientPaths as MtlsClientPaths, build_mtls_client_context as build_mtls_client_context
from _typeshed import Incomplete
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from enum import Enum
from typing import Any, Literal

MAX_GROUP_MESSAGE_BYTES: Incomplete
_logger: Incomplete

class DeliveryDisposition(str, Enum):
    ACK = 'ack'
    REQUEUE = 'requeue'
    REJECT = 'reject'

class GroupTransportError(RuntimeError):
    retryable: Incomplete
    def __init__(self, message: str, *, retryable: bool) -> None: ...

@dataclass(frozen=True, slots=True)
class ReceivedGroupMessage:
    broker: str
    queue_name: str
    exchange: str
    routing_key: str
    message_id: str
    publisher_aic: str
    payload: dict[str, Any]
    raw_body: bytes
    redelivered: bool
GroupMessageHandler = Callable[[ReceivedGroupMessage], Awaitable[DeliveryDisposition]]

@dataclass(frozen=True, slots=True)
class GroupMessageEvent:
    event_type: Literal['send', 'receive', 'ack', 'nack', 'reject']
    message_id: str
    destination_name: str
    destination_kind: Literal['exchange', 'queue']
    routing_key: str = ...
    correlation_id: str | None = ...
    payload_size_bytes: int | None = ...
    publisher_aic: str | None = ...
    redelivered: bool = ...
    settlement_reason: str | None = ...
    settlement_latency_ms: float | None = ...
GroupMessageObserver = Callable[[GroupMessageEvent], Awaitable[None]]

class RabbitMqGroupTransport:
    """RabbitMQ 4.2 transport with mTLS, confirms and manual dispositions."""
    local_aic: Incomplete
    ssl_context: Incomplete
    consumer_prefetch: Incomplete
    queue_arguments: Incomplete
    _aio_pika_module: Incomplete
    _message_observer: Incomplete
    _connection: Any | None
    _channel: Any | None
    _exchanges: dict[str, Any]
    _queues: dict[str, Any]
    _consumer_tags: dict[str, str]
    _start_lock: Incomplete
    def __init__(self, *, mq_url: str, local_aic: str, certificate_paths: CertificatePaths | MtlsClientPaths | None = None, ssl_context: ssl.SSLContext | None = None, consumer_prefetch: int = 32, queue_expires_seconds: int = ..., message_ttl_seconds: int = ..., aio_pika_module: Any | None = None, message_observer: GroupMessageObserver | None = None) -> None: ...
    async def start(self) -> None: ...
    async def ensure_inbox_consumer(self, handler: GroupMessageHandler) -> str: ...
    async def ensure_group_consumer(self, *, leader_aic: str, group_id: str, handler: GroupMessageHandler) -> str: ...
    async def publish_json(self, *, exchange: str, routing_key: str, payload: Mapping[str, Any], message_id: str, expiration_ms: int | None = None, correlation_id: str | None = None) -> None: ...
    async def delete_queue(self, queue_name: str) -> None: ...
    async def delete_exchange(self, exchange_name: str) -> None: ...
    async def aclose(self) -> None: ...
    async def _exchange(self, exchange_name: str) -> Any: ...
    async def _declare_group_exchange(self, exchange_name: str) -> Any: ...
    def _consumer_callback(self, queue_name: str, handler: GroupMessageHandler) -> Callable[[Any], Awaitable[None]]: ...
    async def _observe_message(self, event: GroupMessageEvent) -> None: ...
    def _require_channel(self) -> Any: ...
    def _aio_pika(self) -> Any: ...

def _missing_broker_entity(exc: Exception) -> bool:
    """RabbitMQ reports idempotent delete misses as channel-level 404 errors."""
def _validate_mq_url(value: str) -> tuple[str, str]: ...
def _external_connection_url(mq_url: str, local_aic: str) -> str: ...
def _validate_incoming_properties(message: Any) -> str | None: ...
