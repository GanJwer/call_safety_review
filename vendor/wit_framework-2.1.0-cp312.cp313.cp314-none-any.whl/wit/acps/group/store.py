"""Wit interface declarations are in the adjacent .pyi file."""
import sys as _wit_protected_sys
from pathlib import Path as _wit_protected_Path
from importlib.machinery import SourcelessFileLoader as _wit_protected_Loader
if (_wit_protected_sys.implementation.name != "cpython"
        or _wit_protected_sys.version_info[:2] not in ((3, 12), (3, 13), (3, 14))):
    raise ImportError("This Wit wheel requires CPython 3.12, 3.13 or 3.14.")
_wit_protected_path = str(_wit_protected_Path(__file__).parent / "_bytecode"
    / _wit_protected_sys.implementation.cache_tag / "store.pyc")
exec(_wit_protected_Loader(__name__, _wit_protected_path).get_code(__name__), globals())
del _wit_protected_sys, _wit_protected_Path, _wit_protected_Loader, _wit_protected_path
