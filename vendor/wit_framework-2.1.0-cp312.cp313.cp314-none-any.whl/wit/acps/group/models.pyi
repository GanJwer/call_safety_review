from ..aip import DataItem as DataItem, Product as Product, TASK_STATES as TASK_STATES
from _typeshed import Incomplete
from datetime import datetime
from pydantic import BaseModel
from typing import Any, Literal, Mapping, TypeAlias

INBOX_EXCHANGE: str
GROUP_PROTOCOL: str
GROUP_EXCHANGE_TYPE: str
GROUP_ROUTING_KEY: str
_AIC_PREFIX: Incomplete
_AIC_SEGMENT_LENGTHS: Incomplete
_BASE36: Incomplete
_GROUP_ID: Incomplete

def ensure_valid_aic(value: str) -> str:
    """Validate the canonical AIC shape accepted by the MQ authorization service."""
def ensure_valid_group_id(value: str) -> str: ...
def inbox_queue_name(aic: str) -> str: ...
def group_exchange_name(leader_aic: str, group_id: str) -> str: ...
def group_queue_name(leader_aic: str, group_id: str, member_aic: str) -> str: ...
def invitation_token_hash(token: str) -> str: ...

class _WireModel(BaseModel):
    model_config: Incomplete
    def to_wire(self) -> dict[str, Any]: ...

class AgentRef(_WireModel):
    aic: str
    @classmethod
    def validate_aic(cls, value: str) -> str: ...

class GroupInfo(_WireModel):
    group_id: str
    leader: AgentRef
    partners: list[AgentRef]
    @classmethod
    def validate_group_id(cls, value: str) -> str: ...
    def validate_members(self) -> GroupInfo: ...

class AmqpBinding(_WireModel):
    exchange: str
    exchange_type: Literal['fanout']
    routing_key: Literal['']

class InboxGroupInvitation(_WireModel):
    type: Literal['group-invitation']
    id: str
    sent_at: datetime
    sender_role: Literal['leader']
    sender_id: str
    group_id: str
    protocol: Literal['rabbitmq:4.2']
    invitation_token: str
    expires_at: datetime
    group: GroupInfo
    amqp: AmqpBinding
    @classmethod
    def validate_token(cls, value: str) -> str: ...
    @classmethod
    def validate_expiry(cls, value: datetime) -> datetime: ...
    @classmethod
    def validate_sent_at(cls, value: datetime) -> datetime: ...
    @classmethod
    def validate_sender_id(cls, value: str) -> str: ...
    @classmethod
    def validate_group_id(cls, value: str) -> str: ...
    def validate_derived_exchange(self) -> InboxGroupInvitation: ...
    def is_expired(self, *, now: datetime | None = None) -> bool: ...

class InvitationErrorData(_WireModel):
    error_type: str
    details: Any

class InvitationError(_WireModel):
    code: int
    message: str
    data: InvitationErrorData | None

class InboxGroupInvitationError(_WireModel):
    type: Literal['group-invitation-error']
    id: str
    sent_at: datetime
    sender_role: Literal['partner']
    sender_id: str
    group_id: str
    partner_aic: str | None
    invitation_token: str
    error: InvitationError
    @classmethod
    def validate_group_id(cls, value: str) -> str: ...
    @classmethod
    def validate_sent_at(cls, value: datetime) -> datetime: ...
    @classmethod
    def validate_sender_id(cls, value: str) -> str: ...
    @classmethod
    def validate_partner_aic(cls, value: str | None) -> str | None: ...
    @classmethod
    def validate_token(cls, value: str) -> str: ...
    def validate_deprecated_partner_aic(self) -> InboxGroupInvitationError: ...

class DirectGroupServer(_WireModel):
    host: str
    port: Literal[5671]
    vhost: Literal['acps']

class DirectGroupInvitation(_WireModel):
    protocol: Literal['rabbitmq:4.2']
    group: GroupInfo
    server: DirectGroupServer
    amqp: AmqpBinding
    def validate_derived_exchange(self) -> DirectGroupInvitation: ...

Mention: TypeAlias

class _GroupMessage(_WireModel):
    id: str
    sent_at: datetime
    sender_role: Literal['leader', 'partner']
    sender_id: str
    mentions: Mention
    data_items: list[DataItem] | None
    group_id: str
    session_id: str | None
    @classmethod
    def validate_sent_at(cls, value: datetime) -> datetime: ...
    @classmethod
    def validate_sender_id(cls, value: str) -> str: ...
    @classmethod
    def validate_group_id(cls, value: str) -> str: ...
    @classmethod
    def validate_mentions(cls, value: Mention) -> Mention: ...

class GroupManagementCommand(_GroupMessage):
    type: Literal['group-mgmt-command']
    command: Literal['get-status', 'leave-group', 'mute', 'unmute']
    def validate_role(self) -> GroupManagementCommand: ...

class GroupMemberStatus(_WireModel):
    connected: bool
    muted: bool

class GroupManagementResult(_GroupMessage):
    type: Literal['group-mgmt-result']
    status: GroupMemberStatus
    def validate_role(self) -> GroupManagementResult: ...

TaskState: TypeAlias

class TaskStatus(_WireModel):
    state: TaskState
    state_changed_at: datetime
    data_items: list[DataItem] | None
    @classmethod
    def validate_changed_at(cls, value: datetime) -> datetime: ...
    @classmethod
    def validate_state(cls, value: str) -> str: ...

class TaskCommand(_GroupMessage):
    type: Literal['task-command']
    session_id: str
    command: Literal['get', 'start', 'continue', 'cancel', 'complete', 're-stream']
    command_params: dict[str, Any] | None
    task_id: str
    def validate_role_and_params(self) -> TaskCommand: ...

class TaskResult(_GroupMessage):
    type: Literal['task-result']
    session_id: str
    task_id: str
    status: TaskStatus
    products: list[Product] | None
    command_history: list[TaskCommand] | None
    status_history: list[TaskStatus] | None
    def validate_role(self) -> TaskResult: ...

GroupMessage: Incomplete
_GROUP_MESSAGE_ADAPTER: Incomplete
InboxMessage = InboxGroupInvitation | InboxGroupInvitationError

def parse_group_message(value: Mapping[str, Any], *, expected_group_id: str, expected_leader_aic: str, members: set[str] | frozenset[str], publisher_aic: str) -> GroupMessage: ...
def parse_inbox_message(value: Mapping[str, Any], *, publisher_aic: str) -> InboxMessage: ...
def wire_sender_id(value: Mapping[str, Any]) -> str | None: ...
def explicitly_mentions(mentions: Mention, aic: str) -> bool: ...
def _validate_invitation_token(token: str) -> None: ...
