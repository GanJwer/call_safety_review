import ssl
from ..identity import CertificatePaths as CertificatePaths
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True, slots=True)
class MtlsClientPaths:
    client_certificate: Path
    client_private_key: Path
    trust_bundle: Path

def build_mtls_client_context(certificate_paths: CertificatePaths | MtlsClientPaths) -> ssl.SSLContext:
    """Create the shared TLS 1.3 mTLS client context for MQ and Group API."""
