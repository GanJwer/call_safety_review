from ..acs_contract import REGISTRY_ACS_PROTOCOL_VERSION as REGISTRY_ACS_PROTOCOL_VERSION
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class CompatibilityManifest:
    runtime_profile: str
    acps_spec_version: str = ...
    adapter_version: str = ...
    def to_dict(self) -> dict[str, Any]: ...

@dataclass(frozen=True)
class CoverageSet:
    supported: list[str] = field(default_factory=list)
    blocked: list[str] = field(default_factory=list)
    unconfigured: list[str] = field(default_factory=list)
    def to_dict(self) -> dict[str, Any]: ...

class EvidenceCollector:
    def collect(self, *, compiled: Any, enrollment_state: dict[str, Any]) -> dict[str, Any]: ...
