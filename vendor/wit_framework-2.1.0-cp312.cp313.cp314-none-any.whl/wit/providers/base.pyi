from ..kernel.content import ContentKind, ContentPart
from ..kernel.messages import Message as Message, ModelRequest as ModelRequest, ModelResponse as ModelResponse, ModelStreamEvent as ModelStreamEvent, ToolCall as ToolCall
from _typeshed import Incomplete
from dataclasses import dataclass
from typing import Any, AsyncIterator, Awaitable, Callable, Protocol, Sequence

__all__ = ['ContentTransform', 'ContentTransformContext', 'Message', 'ModelProvider', 'ModelRequest', 'ModelResponse', 'ModelStreamEvent', 'ProviderCapabilities', 'StreamingModelProvider', 'ToolCall', 'UnsupportedContentError', 'prepare_messages_for_provider']

@dataclass(frozen=True, slots=True)
class ProviderCapabilities:
    provider: str
    api: str
    input_modalities: frozenset[ContentKind]
    output_modalities: frozenset[ContentKind]
    streaming: bool = ...
    tools: bool = ...

class UnsupportedContentError(ValueError):
    provider: Incomplete
    role: Incomplete
    part: Incomplete
    reason: Incomplete
    def __init__(self, *, provider: str, role: str, part: ContentPart, reason: str) -> None: ...

@dataclass(frozen=True, slots=True)
class ContentTransformContext:
    provider: str
    role: str
    capabilities: ProviderCapabilities
    reason: str
TransformResult = str | ContentPart | Sequence[ContentPart] | None
TransformHandler = Callable[[ContentPart, ContentTransformContext], TransformResult | Awaitable[TransformResult]]

@dataclass(frozen=True, slots=True)
class ContentTransform:
    """Explicit business-layer conversion for a provider-unsupported modality."""
    source_type: ContentKind
    handler: TransformHandler
    name: str | None = ...
    async def apply(self, part: ContentPart, context: ContentTransformContext) -> list[ContentPart] | None: ...

class ModelProvider(Protocol):
    @property
    def capabilities(self) -> ProviderCapabilities: ...
    def supports_content(self, part: ContentPart, *, role: str) -> tuple[bool, str | None]: ...
    async def complete(self, request: ModelRequest) -> ModelResponse: ...

class StreamingModelProvider(ModelProvider, Protocol):
    async def stream(self, request: ModelRequest) -> AsyncIterator[ModelStreamEvent]: ...

async def prepare_messages_for_provider(messages: Sequence[Message], provider: Any, transforms: Sequence[ContentTransform]) -> list[Message]:
    """Apply only explicitly registered transforms before a provider request.

    Providers without the optional ``supports_content`` contract are left alone;
    their own adapter remains responsible for validation.
    """
