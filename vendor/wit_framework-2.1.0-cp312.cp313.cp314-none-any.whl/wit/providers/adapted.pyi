from ..kernel.content import ContentKind, ContentPart
from .base import ModelRequest, ModelResponse, ModelStreamEvent, ProviderCapabilities
from _typeshed import Incomplete
from collections.abc import AsyncIterator, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Awaitable, Literal

__all__ = ['AdaptedModelProvider', 'GatewayAdaptationError', 'GatewayAdapter', 'GatewayAdapterContext', 'JsonEncodedToolArgumentsAdapter']

@dataclass(frozen=True, slots=True)
class GatewayAdapterContext:
    """Non-secret context shared with one provider-scoped gateway adapter."""
    operation: Literal['complete', 'stream']
    capabilities: ProviderCapabilities
    model: str | None = ...

class GatewayAdaptationError(RuntimeError):
    """A fail-closed error raised only for adapter hook failures.

    The source exception type is retained, but its message and default traceback
    chain are suppressed because third-party payloads may contain secrets.
    """
    adapter: Incomplete
    stage: Incomplete
    operation: Incomplete
    reason: Incomplete
    cause_type: Incomplete
    def __init__(self, *, adapter: str, stage: GatewayStage, operation: GatewayOperation, reason: str, cause_type: str | None = None) -> None: ...

class GatewayAdapter:
    """Identity adapter base class; override only the hooks a gateway needs.

    Hooks may be synchronous or asynchronous. They should return a new value or
    the unchanged input and must not log credentials or raw secret-bearing
    payloads. Request hooks run in configured order; inbound hooks run in the
    reverse order so adapters compose like nested middleware.

    ``added_input_modalities`` must stay empty unless ``adapt_request`` converts
    those user inputs into content natively supported by the wrapped provider.
    """
    name: str
    added_input_modalities: frozenset[ContentKind]
    def adapt_request(self, request: ModelRequest, context: GatewayAdapterContext) -> ModelRequest | Awaitable[ModelRequest]: ...
    def adapt_response(self, request: ModelRequest, response: ModelResponse, context: GatewayAdapterContext) -> ModelResponse | Awaitable[ModelResponse]: ...
    def adapt_stream_event(self, request: ModelRequest, event: ModelStreamEvent, context: GatewayAdapterContext) -> ModelStreamEvent | Awaitable[ModelStreamEvent]: ...
    def aclose(self) -> None | Awaitable[None]: ...

class AdaptedModelProvider:
    """Explicitly apply gateway compatibility logic around a ModelProvider.

    The wrapped provider remains the sole owner of its wire protocol and SDK.
    This wrapper only operates on Wit's normalized request, response, and stream
    event objects. Constructing the original provider directly keeps every
    adapter disabled.
    """
    provider: Incomplete
    adapters: Incomplete
    _adapter_names: Incomplete
    _adapter_entries: Incomplete
    _adapter_modalities: Incomplete
    _added_input_modalities: Incomplete
    _closed: bool
    _close_lock: Incomplete
    def __init__(self, provider: Any, *, adapters: Sequence[GatewayAdapter]) -> None: ...
    @property
    def capabilities(self) -> ProviderCapabilities: ...
    @property
    def model(self) -> str | None: ...
    @property
    def gateway_adapter_names(self) -> tuple[str, ...]: ...
    @property
    def closed(self) -> bool: ...
    def settings(self) -> dict[str, Any]: ...
    def supports_content(self, part: ContentPart, *, role: str) -> tuple[bool, str | None]: ...
    async def complete(self, request: ModelRequest) -> ModelResponse: ...
    async def stream(self, request: ModelRequest) -> AsyncIterator[ModelStreamEvent]: ...
    async def aclose(self) -> None: ...
    def _context(self, operation: Literal['complete', 'stream']) -> GatewayAdapterContext: ...
    def _content_adapter_for(self, request: ModelRequest) -> str | None: ...
    def _ensure_provider_content(self, request: ModelRequest, *, adapter_name: str | None, operation: Literal['complete', 'stream']) -> None: ...
    async def _adapt_request(self, request: ModelRequest, context: GatewayAdapterContext) -> ModelRequest: ...
    async def _adapt_response(self, request: ModelRequest, response: ModelResponse, context: GatewayAdapterContext) -> ModelResponse: ...
    async def _adapt_stream_event(self, request: ModelRequest, event: ModelStreamEvent, context: GatewayAdapterContext) -> ModelStreamEvent: ...
    def _ensure_open(self) -> None: ...

class JsonEncodedToolArgumentsAdapter(GatewayAdapter):
    """Decode explicitly configured array/object tool arguments exactly once.

    Invalid JSON or a decoded value of the wrong declared container type is left
    unchanged so Wit's ordinary tool-schema validation can report the error.
    No tool or field is inferred from a provider URL or model name.
    """
    name: str
    fields: Incomplete
    def __init__(self, fields: Mapping[str, Mapping[str, JsonContainerType]], *, name: str | None = None) -> None: ...
    def adapt_response(self, request: ModelRequest, response: ModelResponse, context: GatewayAdapterContext) -> ModelResponse: ...
